import java.util.Scanner;

//program created and finished on August 31st, 2024.
// this program allows the user to input a binary number into the terminal, and then have it be converted to the "true" value. if someone inputted 1111, in binary,  that represents 15. however, lets say someone 
//inputed "mario." well, the program cant exactly convert that. so we must make exceptions for when it detects an input that isnt in binary, so anything other than 0s and 1s are invalid.

//this is how we tell if an error is inputted, or anything other than 0 or 1.
class BinaryFormatException extends Exception {

    //if we recieve an error we must send a message, which we define this message later on. remember this!
    public BinaryFormatException(String message) {
        super(message);
    }
}

public class App {
    public static void main(String[] args) {

        //this is our scanner, we ask the user to input a string. pretty standard stuff. we get our input to use for later.
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter binary string: ");
        String binaryString = scanner.nextLine();

        try {
            //this is how we get our binary string to its decimal value, by using bin2dec.
            int decimalValue = bin2Dec(binaryString);

            //if everything is swell, it outputs the decimal value!
            System.out.println(decimalValue);

            //HOWEVER, if it isnt, we must "catch" that it isnt. this is when we inform the user that it isnt correct.
        } catch (BinaryFormatException e) {

            //we get our message we define below in the code, and then inform the user.
            System.out.println(e.getMessage());
        }

        //we obviously must close our scanner...
        scanner.close();
    }

    //here is where we convert our string to decimal. if it is not a binary number, this is where we catch it.
    public static int bin2Dec(String binaryString) throws BinaryFormatException {
        //this is how we check each character in the string
        for (int i = 0; i < binaryString.length(); i++) {

            //if a character is not a 1 or a 0, we then throw our exception. informing the user with our message!
            if (binaryString.charAt(i) != '0' && binaryString.charAt(i) != '1') {
                throw new BinaryFormatException("You did not input a binary string.");
            }
        }

        //finally if the string is fine, we just convert the string to a decimal using base 2.
        return Integer.parseInt(binaryString, 2);
    }
}
